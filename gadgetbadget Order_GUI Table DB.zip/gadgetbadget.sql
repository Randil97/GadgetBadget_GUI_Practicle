-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2021 at 08:09 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gadgetbadget`
--

-- --------------------------------------------------------

--
-- Table structure for table `ordertable`
--

CREATE TABLE `ordertable` (
  `orderID` int(11) NOT NULL,
  `orderCode` varchar(15) NOT NULL,
  `orderType` varchar(50) NOT NULL,
  `customerName` varchar(50) NOT NULL,
  `customerContact` varchar(50) NOT NULL,
  `totalAmount` double(20,2) NOT NULL,
  `cardNo` int(11) NOT NULL,
  `cvvNo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ordertable`
--

INSERT INTO `ordertable` (`orderID`, `orderCode`, `orderType`, `customerName`, `customerContact`, `totalAmount`, `cardNo`, `cvvNo`) VALUES
(1001, '100', 'zip', 'janaka', '714563242', 50000.00, 2147483647, 678),
(1002, '101', 'zip', 'anuka', '776675444', 30000.00, 887533412, 123),
(1005, '104', 'Zip', 'suranga', '751119812', 15000.00, 1919191919, 432),
(1006, '105', 'Zip', 'jeewa', '784147721', 18000.00, 776512345, 771),
(1007, '106', 'Zip', 'prasad', '774551472', 18000.00, 443217542, 885),
(1008, '104', 'Mega', 'Rusira', '075221512', 35000.00, 1212121212, 556),
(1009, '106', 'Mega', 'Jeewan', '075221512', 35000.00, 345221345, 661),
(1010, '110', 'Zip', 'Herath', '0719237069', 28000.00, 992344516, 414);

-- --------------------------------------------------------

--
-- Table structure for table `order_gui`
--

CREATE TABLE `order_gui` (
  `orderID` int(11) NOT NULL,
  `orderCode` varchar(15) NOT NULL,
  `orderType` varchar(50) NOT NULL,
  `customerName` varchar(50) NOT NULL,
  `customerContact` varchar(50) NOT NULL,
  `totalAmount` varchar(20) NOT NULL,
  `cardNo` varchar(20) NOT NULL,
  `cvvNo` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_gui`
--

INSERT INTO `order_gui` (`orderID`, `orderCode`, `orderType`, `customerName`, `customerContact`, `totalAmount`, `cardNo`, `cvvNo`) VALUES
(1, '765', 'Mega', 'Janith', '0719234778', '15000.0', '1233112189', '223'),
(3, '667', 'mega', 'Jagath', '0715542776', '45000.0', '7764445263', '543'),
(7, '445', 'Mega', 'Chanaka', '713315121', '15000', '7767121251', '445'),
(8, '123', 'Zip', 'Himash', '712211211', '25000.0', '990978122', '951');

-- --------------------------------------------------------

--
-- Table structure for table `order_tab`
--

CREATE TABLE `order_tab` (
  `orderID` int(20) NOT NULL,
  `orderCode` varchar(10) NOT NULL,
  `customerID` varchar(20) NOT NULL,
  `customerEmail` varchar(40) NOT NULL,
  `customerName` varchar(40) NOT NULL,
  `totalAmount` decimal(10,3) NOT NULL,
  `cardNo` varchar(20) NOT NULL,
  `cvvNo` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `pid` int(11) NOT NULL,
  `project_category` varchar(255) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `short_des` varchar(255) NOT NULL,
  `price` varchar(55) NOT NULL,
  `date` varchar(55) NOT NULL,
  `project_goal` varchar(255) NOT NULL,
  `long_des` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`pid`, `project_category`, `project_name`, `short_des`, `price`, `date`, `project_goal`, `long_des`) VALUES
(1, 'Art', 'Design', 'hi this is Project', '1000', '2021-04-13', 'very goals', 'This is long description'),
(2, 'gg', 'ee', 'gg', '34', '2', 'hh', 'jjj');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ordertable`
--
ALTER TABLE `ordertable`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `order_gui`
--
ALTER TABLE `order_gui`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `order_tab`
--
ALTER TABLE `order_tab`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ordertable`
--
ALTER TABLE `ordertable`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1011;

--
-- AUTO_INCREMENT for table `order_gui`
--
ALTER TABLE `order_gui`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order_tab`
--
ALTER TABLE `order_tab`
  MODIFY `orderID` int(20) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
